var struct_r_a_m_p___s_t_a_t__t =
[
    [ "event_pos_reached", "struct_r_a_m_p___s_t_a_t__t.html#af2f99147366ebe823631e433fa42fd1d", null ],
    [ "event_stop_l", "struct_r_a_m_p___s_t_a_t__t.html#abb35805c46c1afadde27314b6945fa99", null ],
    [ "event_stop_r", "struct_r_a_m_p___s_t_a_t__t.html#a78d14ef74b35ca930543b811146888e7", null ],
    [ "event_stop_sg", "struct_r_a_m_p___s_t_a_t__t.html#a0d4e3620b45309928e20dff2bc42bc4d", null ],
    [ "position_reached", "struct_r_a_m_p___s_t_a_t__t.html#aa95d5ea4b418b03cb5c728cd93420a08", null ],
    [ "second_move", "struct_r_a_m_p___s_t_a_t__t.html#a477c1118f157b18f8794ee167165ef4f", null ],
    [ "sr", "struct_r_a_m_p___s_t_a_t__t.html#a3a668fe9ae2c3ea9ef17a2dff619c7b4", null ],
    [ "status_latch_l", "struct_r_a_m_p___s_t_a_t__t.html#a3c5ffe69808856366aafbcfbc35cba89", null ],
    [ "status_latch_r", "struct_r_a_m_p___s_t_a_t__t.html#a3909cc990a5587e2cbe46453d2561367", null ],
    [ "status_sg", "struct_r_a_m_p___s_t_a_t__t.html#aedf13ab33a2336d1462c424c3823c251", null ],
    [ "status_stop_l", "struct_r_a_m_p___s_t_a_t__t.html#aeac3fcde5333de6cb51883fc60576902", null ],
    [ "status_stop_r", "struct_r_a_m_p___s_t_a_t__t.html#a4b7e4349b0c73e7586d46cb931cd67ba", null ],
    [ "t_zerowait_active", "struct_r_a_m_p___s_t_a_t__t.html#aed74e5a1215c5aab2a5036dbb9882814", null ],
    [ "velocity_reached", "struct_r_a_m_p___s_t_a_t__t.html#a8fb68c37e277414ce37b2d2e6b532705", null ],
    [ "vzero", "struct_r_a_m_p___s_t_a_t__t.html#a27ba60eb6afc7ee4b91284aa4e7f98ab", null ]
];