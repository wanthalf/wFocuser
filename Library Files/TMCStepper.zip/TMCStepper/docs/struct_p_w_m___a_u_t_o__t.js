var struct_p_w_m___a_u_t_o__t =
[
    [ "pwm_grad_auto", "struct_p_w_m___a_u_t_o__t.html#a4c820661f7f3a37075157d8f01e36d7e", null ],
    [ "pwm_ofs_auto", "struct_p_w_m___a_u_t_o__t.html#ac3759715617346859064adb51b0e0a62", null ],
    [ "sr", "struct_p_w_m___a_u_t_o__t.html#af4f71fd86c3c3f36d278220aa80bea8d", null ]
];