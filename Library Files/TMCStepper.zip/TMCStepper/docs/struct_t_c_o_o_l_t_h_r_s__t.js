var struct_t_c_o_o_l_t_h_r_s__t =
[
    [ "sr", "struct_t_c_o_o_l_t_h_r_s__t.html#a685016afa5b0b58f961c5b84d034a97c", null ]
];