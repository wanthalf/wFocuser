var struct_s_g_c_s_c_o_n_f__t =
[
    [ "__pad0__", "struct_s_g_c_s_c_o_n_f__t.html#ac700dc192436c3c5427bcd3ded977faa", null ],
    [ "__pad1__", "struct_s_g_c_s_c_o_n_f__t.html#a0dc5ee2028f0045ab27a1e2bab7d7bcd", null ],
    [ "cs", "struct_s_g_c_s_c_o_n_f__t.html#a202ff12cb42fb3cc06d1de583bc9b363", null ],
    [ "sfilt", "struct_s_g_c_s_c_o_n_f__t.html#ae5e9f0375ef6466b306a312827a2c2aa", null ],
    [ "sgt", "struct_s_g_c_s_c_o_n_f__t.html#a4fc3d0af55a4942b91cd073f768f20f7", null ],
    [ "sr", "struct_s_g_c_s_c_o_n_f__t.html#a66fe3461b9a236c9b9021abd678f627c", null ]
];