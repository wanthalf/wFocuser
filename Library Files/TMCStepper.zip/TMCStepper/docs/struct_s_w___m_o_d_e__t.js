var struct_s_w___m_o_d_e__t =
[
    [ "en_latch_encoder", "struct_s_w___m_o_d_e__t.html#a38b9876420f5c799e04d2aeb182ae413", null ],
    [ "en_softstop", "struct_s_w___m_o_d_e__t.html#a90ada92f5eab3f73e995389ce60f8af4", null ],
    [ "latch_l_active", "struct_s_w___m_o_d_e__t.html#afe97462a02c7a0423f8904d45ce6a99c", null ],
    [ "latch_l_inactive", "struct_s_w___m_o_d_e__t.html#a2121bfd9849c1b8d509c9b8560941fad", null ],
    [ "latch_r_active", "struct_s_w___m_o_d_e__t.html#a11c10322841539f624836d78bed7278e", null ],
    [ "latch_r_inactive", "struct_s_w___m_o_d_e__t.html#aaedac544cc895656e81562ee502a8d14", null ],
    [ "pol_stop_l", "struct_s_w___m_o_d_e__t.html#a27997a1e5c0e139b9b2cd90ec133ceb6", null ],
    [ "pol_stop_r", "struct_s_w___m_o_d_e__t.html#a27fcd39d4a80cff341264a47fec8f1af", null ],
    [ "sg_stop", "struct_s_w___m_o_d_e__t.html#a928b00187288c54654e6e316a5963c84", null ],
    [ "sr", "struct_s_w___m_o_d_e__t.html#a6db8a27da14e18f2869b7c69728e23c2", null ],
    [ "stop_l_enable", "struct_s_w___m_o_d_e__t.html#a77188de0f1dde018ba3c59cd34706d0c", null ],
    [ "stop_r_enable", "struct_s_w___m_o_d_e__t.html#ac04574fb2d540725306e00811e72ae0d", null ],
    [ "swap_lr", "struct_s_w___m_o_d_e__t.html#a62946843370651f3e56f033e537a7473", null ]
];