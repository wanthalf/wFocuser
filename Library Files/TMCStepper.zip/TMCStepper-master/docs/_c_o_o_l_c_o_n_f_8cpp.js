var _c_o_o_l_c_o_n_f_8cpp =
[
    [ "GET_REG", "_c_o_o_l_c_o_n_f_8cpp.html#a851c499b52890f1c89886e8cf64a4415", null ],
    [ "SET_REG", "_c_o_o_l_c_o_n_f_8cpp.html#a6e4f7ba2fdd5a548e9a0383905ada143", null ]
];