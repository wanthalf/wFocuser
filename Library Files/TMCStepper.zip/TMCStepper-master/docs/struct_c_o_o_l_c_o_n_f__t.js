var struct_c_o_o_l_c_o_n_f__t =
[
    [ "sedn", "struct_c_o_o_l_c_o_n_f__t.html#a3d980b17ea916820c3bf4dd885a19875", null ],
    [ "seimin", "struct_c_o_o_l_c_o_n_f__t.html#ab4e423518542b0a63fd9105af86598b9", null ],
    [ "semax", "struct_c_o_o_l_c_o_n_f__t.html#a8a0b1d9f35fbdc18a795e61b4a6077c0", null ],
    [ "semin", "struct_c_o_o_l_c_o_n_f__t.html#a19d952e9aaa8c6df041f1e2ee121bd43", null ],
    [ "seup", "struct_c_o_o_l_c_o_n_f__t.html#a15e5f4644beb23a4ab119aaecce197fd", null ],
    [ "sfilt", "struct_c_o_o_l_c_o_n_f__t.html#aab91a0d2c33ccafdd76c941cb74f5667", null ],
    [ "sgt", "struct_c_o_o_l_c_o_n_f__t.html#a9e46b896b25780ceb7e501089c0ffd99", null ],
    [ "sr", "struct_c_o_o_l_c_o_n_f__t.html#ab6e1727791c9833eeeda31f676522e9f", null ]
];