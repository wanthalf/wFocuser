var class_t_m_c5161_stepper =
[
    [ "TMC5161Stepper", "class_t_m_c5161_stepper.html#afff5eba2e407c3bc1ad9aabdbcffeb9f", null ],
    [ "TMC5161Stepper", "class_t_m_c5161_stepper.html#a67797469ad054e42ec6086b37b81fbdd", null ],
    [ "TMC5161Stepper", "class_t_m_c5161_stepper.html#a5ad0292bfabaf69e4bbd1b7569bf3967", null ]
];