// Copyright 2017 David Conran

#include "myfp2eIRtimer.h"
#include <Arduino.h>

// Class constructor.
IRtimer::IRtimer() { reset(); }

/// Resets the IRtimer object. I.e. The counter starts again from now.
void IRtimer::reset() {
  start = micros();
}

/// Calculate how many microseconds have elapsed since the timer was started.
/// @return Nr. of microseconds.
uint32_t IRtimer::elapsed() {
  uint32_t now = micros();
  if (start <= now)      // Check if the system timer has wrapped.
    return now - start;  // No wrap.
  else
    return UINT32_MAX - start + now;  // Has wrapped.
}

/// Class constructor.
TimerMs::TimerMs() { reset(); }

/// Resets the TimerMs object. I.e. The counter starts again from now.
void TimerMs::reset() {
#ifndef UNIT_TEST
  start = millis();
#else
  start = _TimerMs_unittest_now;
#endif
}

/// Calculate how many milliseconds have elapsed since the timer was started.
/// @return Nr. of milliseconds.
uint32_t TimerMs::elapsed() {
  uint32_t now = millis();
  if (start <= now)      // Check if the system timer has wrapped.
    return now - start;  // No wrap.
  else
    return UINT32_MAX - start + now;  // Has wrapped.
}

