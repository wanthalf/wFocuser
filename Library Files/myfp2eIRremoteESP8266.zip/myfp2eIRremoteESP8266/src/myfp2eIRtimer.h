// Copyright 2017 David Conran

#ifndef myfp2eIRTIMER_H_
#define myfp2eIRTIMER_H_

#define __STDC_LIMIT_MACROS
#include <stdint.h>

// Classes

/// This class offers a simple counter in micro-seconds since instantiated.
/// @note Handles when the system timer wraps around (once).
class IRtimer {
 public:
  IRtimer();
  void reset();
  uint32_t elapsed();
 private:
  uint32_t start;  ///< Time in uSeconds when the class was instantiated/reset.
};

/// This class offers a simple counter in milli-seconds since instantiated.
/// @note Handles when the system timer wraps around (once).
class TimerMs {
 public:
  TimerMs();
  void reset();
  uint32_t elapsed();

 private:
  uint32_t start;  ///< Time in mSeconds when the class was instantiated/reset.
};
#endif  // myfp2eIRTIMER_H_
