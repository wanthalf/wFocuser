# myOLED
This library is a cut down library from Grieman's SDD1306ASCIIWire OLED library on Github.
https://github.com/greiman/SSD1306Ascii

A lof of code has been removed, and a few functions added to improve functionality. It has been tested with 
- Arduino Nano
- ESP8266
- ESP32

The modifications were done by
Robert Brown
as part of the myFocuserPro2 focuser project.
